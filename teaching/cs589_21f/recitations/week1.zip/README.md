# week 1

- immutability with strings (regex)
- polymorphism
    - LJXQ
    - Shape

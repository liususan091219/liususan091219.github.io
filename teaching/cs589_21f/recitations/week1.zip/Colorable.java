package week1;

public interface Colorable {
    public void setColor(String color);
    public String getColor();
}

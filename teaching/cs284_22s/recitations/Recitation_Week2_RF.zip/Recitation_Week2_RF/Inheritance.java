public class Inheritance {
    public static void main(String[] args) {
        A a = new B();
        a.setValue(3);

        B b = new B();
        b.setValue(3.0);

        A a = new B();
        a.setValue(2);
        a.setValue(3.0);

        A a1 = new B();
        a.setValue(3.0);

    }
}

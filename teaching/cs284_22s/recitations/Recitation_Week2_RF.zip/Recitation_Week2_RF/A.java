public class A {
    public A() {

    }
    //method 1
    public boolean readFile(String s) {
        return false;
    }

    //method 2
    public boolean setValue(int i) {
        System.out.println("Method 2 gets executed");
        return false;
    }

}

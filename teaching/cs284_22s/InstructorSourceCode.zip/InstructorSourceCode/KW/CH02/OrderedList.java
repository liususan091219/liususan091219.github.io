/*<listing chapter="2" section="10">*/
package KW.CH02;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Iterator;

/**
 * A class to represent an ordered list. The data is stored in a linked
 *  list data field.
 *  @author Koffman & Wolfgang
 */
public class OrderedList<E extends Comparable<E>>
     implements Iterable<E> {

    /** A linked list to contain the data. */
    private LinkedList<E> theList = new LinkedList<E>();

    public OrderedList() {
        theList = new LinkedList<E>();
    }

    /**
     * Insert obj into the list preserving the list's order.
     * @pre The items in the list are ordered.
     * @post obj has been inserted into the list
     *       such that the items are still in order.
     * @param obj The item to be inserted
     */
    public void add(E obj) {
        ListIterator<E> iter = theList.listIterator();
        // Find the insertion position and insert.
        while (iter.hasNext()) {
            if (obj.compareTo(iter.next()) < 0) {
                // Iterator has stepped over the first element
                // that is greater than the element to be inserted.
                // Move the iterator back one.
                iter.previous();
                // Insert the element.
                iter.add(obj);
                // Exit the loop and return.
                return;
            }
        }
        // assert: All items were examined and no item is larger than
        // the element to be inserted.
        // Add the new item to the end of the list.
        iter.add(obj);
    }

    /*<exercise chapter="2" section="10" type="programming" number="2">*/
    /**
     * Insert obj into the list preserving the list's order.
     * Insertion is performed starting at the end of the list
     * @pre The items in the list are ordered.
     * @post obj has been inserted into the list
     *       such that the items are still in order.
     * @param obj The item to be inserted
     */
    public void add2(E obj) {
        ListIterator<E> iter = theList.listIterator(size());
        // Find the insertion position and insert.
        while (iter.hasPrevious()) {
            if (obj.compareTo(iter.previous()) > 0) {
                // Iterator has stepped over the last element
                // that is less than the element to be inserted.
                // Move the iterator back one.
                iter.next();
                // Insert the element.
                iter.add(obj);
                // Exit the loop and return.
                return;
            }
        }
        // assert: All items were examined and no item is larger than
        // the element to be inserted.
        // Add the new item to the end of the list.
        iter.add(obj);
    }
    /*</exercise>*/

    /**
     * Returns the element at the specified position.
     * @param index The index of the specified position
     * @return The element at position index
     */
    E get(int index) {
        return theList.get(index);
    }

    /*<exercise chapter="2" section="10" type="programming" number="1">*/
    /**
     * Returns an iterator to this OrderedList.
     * @return The iterator, positioning it before the first element.
     */
    @Override
    public Iterator<E> iterator() {
        return theList.iterator();
    }

    public int size() {
        return theList.size();
    }

    public void remove(E obj) {
        theList.remove(obj);
    }
    /*</exercise>*/
}
/*</listing>*/

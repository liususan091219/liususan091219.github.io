/** 
 * ShapeInt.java
 * @author: Koffman & Wolfgang
 */

package KW.AXC.drawapp;

public interface ShapeInt {
    double computeArea();
    double computePerimeter();
    void readShapeData();
}

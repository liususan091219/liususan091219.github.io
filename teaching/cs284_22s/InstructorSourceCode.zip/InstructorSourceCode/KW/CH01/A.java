package KW.CH01;

public class A {
  public static void main(String[] args){
	  A x = new B();
      System.out.println(x.m(5.0));
	System.out.println(x.m(5));
  }
	public int m(double x) {
		return 10;
	}
}
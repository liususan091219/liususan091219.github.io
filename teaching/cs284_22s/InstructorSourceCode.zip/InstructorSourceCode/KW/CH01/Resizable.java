/*<exercise chapter="1" section="1" type="programming" number="1">*/
package KW.CH01;

/**
 *  Interface to define the method resize
 */
public interface Resizable {

    /**
     *  Method to resize the object
     */
    void resize();
}
/*</exercise>*/

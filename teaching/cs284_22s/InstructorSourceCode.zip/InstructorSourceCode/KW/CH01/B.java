package KW.CH01;

public class B extends A {

	public int m(double x) {
		return 20;
	}
}
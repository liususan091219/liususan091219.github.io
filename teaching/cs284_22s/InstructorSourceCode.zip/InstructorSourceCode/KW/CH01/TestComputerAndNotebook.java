/*<listing chapter="1" section="3" sequence="1">*/
/**
 * Un-numbered listing in section 1.3
 * @author Koffman and Wolfgang
 */
package KW.CH01;

public class TestComputerAndNotebook {

    /**
     * Tests classes Computer and Notebook. Creates an object of each and
     * displays them.
     * @param args[] No control parameters
     */
    public static void main(String[] args) {
    	Object aThing = new Integer(25);
    	System.out.println(((Integer)aThing).intValue());
     }
}
/*</listing>*/

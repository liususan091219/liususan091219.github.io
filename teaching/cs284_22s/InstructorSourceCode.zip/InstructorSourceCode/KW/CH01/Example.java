package KW.CH01;

public class Example {
	public static void main(String[] args) {
		ATM anATM = new ATMbankAmerica();
	}
}

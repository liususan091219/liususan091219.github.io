package KW.CH01;

public class TestComputer {
    public static void main(String[] args) {

        Computer myComputer = new Computer();
        System.out.println("Get processor" + myComputer.getProcessor());
    }
}

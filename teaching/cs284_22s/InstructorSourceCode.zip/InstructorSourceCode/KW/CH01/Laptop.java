package KW.CH01;

public class Laptop extends Computer {
	
	/* Initializes a Laptop object with all properties
	specified. */
//	public Laptop(String man, String processor, double
//	ram, int disk, double screen, double weight)
//	{
//	super(processor, ram, disk);
//	screenSize = screen;
//	weight = weight;
//	}
	
	public Laptop(String man, String processor, double
			ram, int disk, double screen, double weight)
			{
			manufacturer = man;
			processor = processor;
			ram = ram;
			disk = disk;
			screenSize = screen;
			weight = weight;
			}
	
	// Data fields
	private double screenSize;
	private double weight;
}